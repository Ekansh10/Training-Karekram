import React from "react";
import ListOfCourses from "../listofcourses/listofcourses";

class App extends React.Component {
  render() {
    return <ListOfCourses />;
  }
}

export default App;